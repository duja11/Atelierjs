class Etudiant {
    constructor(nom, prenom, age, cne) {
      this.nom = nom;
      this.prenom = prenom;
      this.age = age;
      this.cne = cne;
    }
  
    etudier() {
      console.log(`${this.nom} ${this.prenom} est en train d'étudier.`);
    }
  }
  
  class Professeur extends Etudiant { 
    constructor(nom, age, cin) {
      super(nom, age); 
      this.cin = cin;
    }
  
    enseigner() {
      console.log(`${this.nom} ${this.prenom} est en train d'enseigner.`);
    }
  }
  
  function trierEtudiants(etudiants) {
    etudiants.sort((a, b) => {
      const nomCompletA = a.nom.toLowerCase() + a.prenom.toLowerCase();
      const nomCompletB = b.nom.toLowerCase() + b.prenom.toLowerCase();
      return nomCompletA.localeCompare(nomCompletB);
    });
  }
  
  const etudiants = [
    new Etudiant("alami", "amine", 20, "KB1234"),
    new Etudiant("Alaoui", "ahmad", 22, "MA5678"),
    new Etudiant("Durant", "Marie", 18, "CNE9012"),
  ];
  
  trierEtudiants(etudiants);
  console.log(etudiants);