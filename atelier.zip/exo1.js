class Voiture {
    constructor(model, marque, année, type, carburant) {
      this.model = model;
      this.marque = marque;
      this.année = année;
      this.type = type;
      this.carburant = carburant;
    }
  }


  let voiture1 = new Voiture("Yaris", "Toyota", 2020, "Citadine", "Essence");
  let voiture2 = new Voiture("Clio", "Renault", 2021, "Citadine", "Essence");
  let voiture3 = new Voiture("308", "Peugeot", 2022, "Compacte", "Diesel");
  let voiture4 = new Voiture("Tucson", "Hyundai", 2023, "SUV", "Hybride");
  let voiture5 = new Voiture("Mustang", "Ford", 2024, "Sportive", "Essence");
  
  class Hyundai extends Voiture {
    constructor(model, marque, année, type, carburant, série, hybride) {
      super(model, marque, année, type, carburant);
      this.série = série;
      this.hybride = hybride;
    }
  
    alarmer() {
      console.log(`Alerte ! La Hyundai ${this.modèle} est en danger !`);
    }
  }
  
  class Ford extends Voiture {
    constructor(model, marque, année, type, carburant, options) {
      super(model, marque, année, type, carburant);
      this.options = options;
    }
  }


  voitures.sort((a, b) => a.année - b.année);

voitures.forEach(voiture => {
  console.log(`Modèle: ${voiture.modèle}, Marque: ${voiture.marque}, Année: ${voiture.année}, Type: ${voiture.type}, Carburant: ${voiture.carburant}`);
});
