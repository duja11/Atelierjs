class Vecteur2D {
    constructor(x = 0, y = 0) {
      this.x = x;
      this.y = y;
    }
  
    afficher() {
      console.log(`Vecteur2D (${this.x}, ${this.y})`);
    }
  
    additionner(vecteur) {
      if (!(vecteur instanceof Vecteur2D)) {
        throw new Error("Le paramètre doit être une instance de Vecteur2D");
      }
      const nouveauX = this.x + vecteur.x;
      const nouveauY = this.y + vecteur.y;
      return new Vecteur2D(nouveauX, nouveauY);
    }
  }
  const vecteur1 = new Vecteur2D(); // Vecteur2D sans paramètre (x = 0, y = 0)
const vecteur2 = new Vecteur2D(5, 3); // Vecteur2D avec paramètres (x = 5, y = 3)

vecteur1.afficher(); // Affiche : Vecteur2D (0, 0)
vecteur2.afficher(); // Affiche : Vecteur2D (5, 3)

const vecteurSomme = vecteur1.additionner(vecteur2);
vecteurSomme.afficher(); // Affiche : Vecteur2D (5, 3)

class Rectangle {
    constructor(longueur = 0, largeur = 0) {
      this.longueur = longueur;
      this.largeur = largeur;
      this.nom = "rectangle";
    }
  
    afficher() {
      console.log(`Rectangle : longueur = ${this.longueur}, largeur = ${this.largeur}`);
    }
  
    surface() {
      return this.longueur * this.largeur;
    }
  }
  
  class Carre extends Rectangle {
    constructor(cote = 0) {
      super(cote, cote); // Appel du constructeur de la classe parente
      this.nom = "carré";
    }
  }
  
  const rectangle = new Rectangle(10, 5);
const carre = new Carre(7);

rectangle.afficher(); // Affiche : Rectangle : longueur = 10, largeur = 5
carre.afficher();    // Affiche : Carré : longueur = 7, largeur = 7

console.log(`Surface du rectangle : ${rectangle.surface()}`); // Affiche : Surface du rectangle : 50
console.log(`Surface du carré : ${carre.surface()}`);        // Affiche : Surface du carré : 49

class Point {
    constructor(x = 0.0, y = 0.0) {
      this.x = x;
      this.y = y;
    }
  }
  
  class Segment {
    constructor(xOrigine, yOrigine, xExtremite, yExtremite) {
      this.orig = new Point(xOrigine, yOrigine);
      this.extrem = new Point(xExtremite, yExtremite);
    }
  }
  